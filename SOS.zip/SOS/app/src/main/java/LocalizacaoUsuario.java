public class LocalizacaoUsuario {
    String latitude, longitude, usuario, status;

    public LocalizacaoUsuario(){

    }
    public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        this.status = status;
    }

    public String getLatitude() {return latitude;}

    public void setLatitude(String latitude) { this.latitude = latitude; }

    //slide 7
    //primeiro
    //linha 9

}
