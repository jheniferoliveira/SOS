package com.example.sos;

import com.google.firebase.auth.FirebaseAuth;

public class AutenticacaoComFirebase {
    //variável estatica permanece na memoria
    private static FirebaseAuth auth;

    // cria metodo estatico para verificar a autenticacao
    public static FirebaseAuth check(){

        if (auth == null) {
            auth = FirebaseAuth.getInstance();
        }
            return auth;
    }
}
