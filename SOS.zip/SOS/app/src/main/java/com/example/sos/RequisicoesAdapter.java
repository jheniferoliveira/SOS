package com.example.sos;

import android.content.Context;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RequisicoesAdapter extends RecyclerView.Adapter<RequisicoesAdapter.MyViewHolder> {

    private List<LocalizacaoUsuario>requisicoes;
    private Context context;
    private LocalizacaoUsuario usuario;

    public RequisicoesAdapter(List<LocalizacaoUsuario> requisicoes, Context context, LocalizacaoUsuario usuario){
        this.requisicoes = requisicoes;
        this.context = context;
        this.usuario = usuario;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View item = LayoutInflater.from(parent.getContext()).inflate(R.layout.adapter_requisicoes, parent, false);

        return  new MyViewHolder(item);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position){
        LocalizacaoUsuario localizacaoUsuario = requisicoes.get(position);

        holder.nome.setText(localizacaoUsuario.getUsuario());
        holder.longitude.setText(localizacaoUsuario.getLongitude());
        holder.latitude.setText(localizacaoUsuario.getLatitude());
        holder.status.setText(localizacaoUsuario.getStatus());
    }

    @Override
    public int getItemCount(){
        return requisicoes.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView nome, status, latitude, longitude;

        public MyViewHolder(View itemView){
            super(itemView);

            nome = itemView.findViewById(R.id.textViewRequisicoesUsuario);
            status = itemView.findViewById(R.id.textViewRequisicoesStatus);
            latitude = itemView.findViewById(R.id.textViewRequisicoesLatitude);
            longitude = itemView.findViewById(R.id.textViewRequisicoesLongitude);
        }
    }
}
