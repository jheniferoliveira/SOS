package com.example.sos;

public class StatusRequisicoes {

    public static String STATUS_AGUARDANDO, STATUS_ANDAMENTO, STATUS_FINALIZADO;

    public StatusRequisicoes(){
        this.STATUS_AGUARDANDO = "Aguardando";
        this.STATUS_ANDAMENTO = "Andamento";
        this.STATUS_FINALIZADO = "Finalizado";
    }

}
