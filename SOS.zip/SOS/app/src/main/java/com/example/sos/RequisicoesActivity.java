package com.example.sos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.widget.AdapterView;
import android.widget.TextView;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;
import java.util.List;

public class RequisicoesActivity extends AppCompatActivity {
    DatabaseReference reference;
    TextView textViewStatus;
    RecyclerView recyclerView;
    List<LocalizacaoUsuario> listaRequisicoes = new ArrayList<>();
    RequisicoesAdapter adapter;
    LocalizacaoUsuario usuario;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_requisicoes);

        textViewStatus = findViewById(R.id.textViewSemRequisicoes);
        recyclerView = findViewById(R.id.recyclerViewRequisicoes);

        usuario = new LocalizacaoUsuario();

        adapter = new RequisicoesAdapter(listaRequisicoes, getApplicationContext(), usuario);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());

        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setHasFixedSize(true);
        recyclerView.setAdapter(adapter);

        //adiciona evento de clique no recycler
        recyclerView.addOnItemTouchListener(
                new RecyclerItemClickListener(
                        getApplicationContext(),


                        recyclerView,
                        new RecyclerItemClickListener.OnItemClickListener() {
                            @Override
                            public void onItemClick(View view, int position) {
                                LocalizacaoUsuario localizacaoUsuario = listaRequisicoes.get(position);

                                Intent i = new Intent(RequisicoesActivity.this, DetalhesPedidoSocorroActivity.class);
                                i.putExtra("usuario", localizacaoUsuario.getUsuario());
                                i.putExtra("latitude", localizacaoUsuario.getLatitude());
                                i.putExtra("longitude", localizacaoUsuario.getLongitude());
                                i.putExtra("status", localizacaoUsuario.getStatus());
                                startActivity(i);

                            }

                            @Override
                            public void onLongItemClick(View view, int position) {

                            }

                            @Override
                            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {

                            }
                        }
                ) {
                    @Override
                    public void onTouchEvent(@NonNull RecyclerView rv, @NonNull MotionEvent e) {

                    }
                }
        );

        //recuperaRequisicoes();

    }
}