package com.example.sos;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class LocalizacaoUsuario {
    String latitude, longitude, usuario, status;

    public LocalizacaoUsuario(){

    }
    public String getStatus(){
        return status;
    }
    public void setStatus(String status){
        this.status = status;
    }

    public String getLatitude() {return latitude;}

    public void setLatitude(String latitude) { this.latitude = latitude; }

    public String getLongitude() {return longitude;}

    public void setLongitude(String longitude) { this.longitude = longitude;}

    public String getUsuario() {return usuario;}

    public void setUsuario(String usuario) { this.usuario = usuario;}

    public void salvaLocalizacao(){
        ConexaoRealtimeDatabase reference = new ConexaoRealtimeDatabase();
        DatabaseReference conn = reference.check();

        conn.child("localização").push().setValue(this);
    }
    public void alteraStatus(LocalizacaoUsuario localizacao, String status, String id){

        DatabaseReference reference = FirebaseDatabase.getInstance().getReference("localizacao");

        this.setStatus(status);

        reference.child(id).setValue(this);

    }
}
