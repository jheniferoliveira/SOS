package com.example.sos;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;

public class cadastroActivity extends AppCompatActivity {

    FirebaseAuth auth;
    DatabaseReference reference;

    EditText editTextNomeC, editTextTelefoneC, editTextEmailC, editTextSenhaC;
    Button buttonSalvar;

    Switch switchTipo;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        auth = AutenticacaoComFirebase.check();

        editTextNomeC = findViewById(R.id.editTextNomeC);
        editTextTelefoneC = findViewById(R.id.editTextTelefoneC);
        editTextEmailC = findViewById(R.id.editTextEmailC);
        editTextSenhaC = findViewById(R.id.editTextSenhaC);
        buttonSalvar = findViewById(R.id.buttonSalvar);

        switchTipo = findViewById(R.id.switchTipo);

        buttonSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(validarcamposcadastro()){
                    cadastraUsuario();
                }
            }
        });
        }


    public String tipoUsuario(){
        return switchTipo.isChecked() ? "Socorrista" : "Usuario"    ;
    }

    public boolean validarcamposcadastro(){
        if (editTextNomeC.getText().toString().isEmpty()){
            Toast.makeText(this,"Preencha o campo nome" ,Toast .LENGTH_SHORT).show();
            editTextNomeC.requestFocus();
            return false;
        }else if (editTextTelefoneC.getText().toString().isEmpty() || editTextTelefoneC.getText().toString().length()< 8){
            Toast.makeText(this,"Preencha o campo telefone" ,Toast .LENGTH_SHORT).show();
            editTextTelefoneC.requestFocus();
            return false;
    }else if (editTextEmailC.getText().toString().isEmpty() || !editTextEmailC.getText().toString().contains("@")){
            Toast.makeText(this,"Preencha o campo E-Mail" ,Toast .LENGTH_SHORT).show();
            editTextEmailC.requestFocus();
            return false;
    }else if (editTextSenhaC.getText().toString().isEmpty() || editTextSenhaC.getText().toString().length() <6) {
            Toast.makeText(this, "Preencha o campo Senha", Toast.LENGTH_SHORT).show();
            editTextSenhaC.requestFocus();
            return false;
           }else {
            return true;
        }

        }


        public void cadastraUsuario(){
        //salva os dados do login
            auth.createUserWithEmailAndPassword(editTextEmailC.getText().toString(), editTextSenhaC.getText().toString())
                    .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()){
                                //instancia a classe usuaria
                                Usuario usuario = new Usuario();
                                //pega o id que foi salvo no processo da cração de login e senha
                                usuario.setId(task.getResult().getUser().getUid());
                                usuario.setEmail(editTextEmailC.getText().toString());
                                usuario.setSenha(editTextSenhaC.getText().toString());
                                usuario.setNome(editTextNomeC.getText().toString());
                                usuario.setTelefone(editTextTelefoneC.getText().toString());
                                usuario.setTipo(tipoUsuario());

                                if(tipoUsuario() == "Usuario"){
                                    startActivity(new Intent(cadastroActivity.this, usuarioActivity.class));
                                }else{
                                    startActivity(new Intent(cadastroActivity.this, socorristaActivity.class));
                                }

                                usuario.cadastraUsuario(task.getResult().getUser().getUid());

                            }else{
                                try{
                                    throw task.getException();
                                }catch (Exception ex){
                                    ex.printStackTrace();
                                }
                            }
                        }
                    });
        }
    }