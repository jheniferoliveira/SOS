package com.example.sos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class DetalhesPedidoSocorroActivity extends AppCompatActivity {
    TextView textViewUsuario, textViewLongitude, textViewLatitude, textViewStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_pedido_socorro);

        //String

    }
}
